package pckg1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class Tester {

	WebDriver driver;

	@BeforeEach
	void setUp() throws Exception {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KATHIR\\Desktop\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.get("https://github.com/DhineshGitHub/Selenium-Screenshort-java");
		driver.manage().window().maximize();

		Thread.sleep(1000);
	}

	@AfterEach
	void tearDown() throws Exception {
		driver.quit();
	}

	@Test
	void test() throws Exception {
		
		TakesScreenshot tk = ((TakesScreenshot)driver);
		
		File scrFile = tk.getScreenshotAs(OutputType.FILE);
		
		File DestFile = new File("C:\\Users\\KATHIR\\Desktop\\img.png");
		
		FileUtils.copyFile(scrFile, DestFile);
		
		Thread.sleep(2000);
	}

}
